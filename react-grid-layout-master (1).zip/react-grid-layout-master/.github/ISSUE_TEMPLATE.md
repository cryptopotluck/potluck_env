Please only submit bugs to this tracker. If you have a feature request, please implement it. This is free software and the author is busy with other projects.

Please use the [WebpackBin Template](https://www.webpackbin.com/bins/-Kvr2qCxorvGMgVMxkmI) to demonstrate your bug. It is much easier for us to help you if you do.
