var DevLayout = require("./examples/0-showcase.jsx");
require("./test-hook.jsx")(DevLayout);
